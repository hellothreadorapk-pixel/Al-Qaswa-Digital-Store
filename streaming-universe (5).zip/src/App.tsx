import React, { useState, useMemo, useRef } from 'react';
import { Header } from './components/Header';
import { CinematicHero } from './components/CinematicHero';
import { CategoryFilter } from './components/CategoryFilter';
import { ServiceCard } from './components/ServiceCard';
import { CartDrawer } from './components/CartDrawer';
import { TrustBadges } from './components/TrustBadges';
import { FAQSection } from './components/FAQSection';
import { Footer } from './components/Footer';
import { SERVICES_DATA, WHATSAPP_NUMBER, WHATSAPP_DISPLAY } from './data/services';
import { CategoryType, CartItem, ServiceItem } from './types';
import { MessageSquare, Info } from 'lucide-react';

export default function App() {
  const [activeCategory, setActiveCategory] = useState<CategoryType>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [inStockOnly, setInStockOnly] = useState<boolean>(false);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const catalogRef = useRef<HTMLDivElement>(null);

  // Filter services dynamically
  const filteredServices = useMemo(() => {
    return SERVICES_DATA.filter((service) => {
      // Category match
      if (activeCategory !== 'all' && service.category !== activeCategory) {
        return false;
      }

      // In Stock filter
      if (inStockOnly && service.stock === 0) {
        return false;
      }

      // Search query match
      if (searchQuery.trim() !== '') {
        const query = searchQuery.toLowerCase().trim();
        const matchesName = service.name.toLowerCase().includes(query);
        const matchesType = service.type?.toLowerCase().includes(query);
        const matchesDesc = service.description?.toLowerCase().includes(query);
        return matchesName || matchesType || matchesDesc;
      }

      return true;
    });
  }, [activeCategory, searchQuery, inStockOnly]);

  // Calculate counts per category
  const categoryCounts = useMemo(() => {
    const counts: Record<CategoryType, number> = {
      all: SERVICES_DATA.length,
      streaming: 0,
      vpn: 0,
      productivity: 0,
      por: 0,
    };

    SERVICES_DATA.forEach((item) => {
      if (counts[item.category] !== undefined) {
        counts[item.category]++;
      }
    });

    return counts;
  }, []);

  // Cart operations
  const handleAddToCart = (service: ServiceItem, quantity: number) => {
    setCartItems((prev) => {
      const existingIndex = prev.findIndex((i) => i.service.id === service.id);
      if (existingIndex > -1) {
        const updated = [...prev];
        updated[existingIndex].quantity += quantity;
        return updated;
      } else {
        return [...prev, { service, quantity }];
      }
    });
  };

  const handleUpdateQuantity = (serviceId: string, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveItem(serviceId);
      return;
    }
    setCartItems((prev) =>
      prev.map((item) =>
        item.service.id === serviceId ? { ...item, quantity } : item
      )
    );
  };

  const handleRemoveItem = (serviceId: string) => {
    setCartItems((prev) => prev.filter((item) => item.service.id !== serviceId));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  // Cart badge calculations
  const totalCartCount = cartItems.reduce((acc, curr) => acc + curr.quantity, 0);
  const totalCartAmount = cartItems.reduce((acc, curr) => {
    const isBulk =
      curr.service.bulkPrice &&
      curr.quantity >= (curr.service.bulkMinQty || 2);
    const unitPrice = isBulk ? curr.service.bulkPrice! : curr.service.price;
    return acc + unitPrice * curr.quantity;
  }, 0);

  const whatsappGeneralUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(
    'Hi Al Qaswa Digital Store! I would like to place an order or ask a question.'
  )}`;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans flex flex-col justify-between selection:bg-blue-600 selection:text-white">
      {/* Top Header */}
      <Header
        cartCount={totalCartCount}
        cartTotal={totalCartAmount}
        onOpenCart={() => setIsCartOpen(true)}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      />

      <main className="flex-1">
        {/* Cinematic 3D Animation Video Showcase */}
        <CinematicHero
          onExploreClick={() => {
            catalogRef.current?.scrollIntoView({ behavior: 'smooth' });
          }}
        />

        {/* Filter Bar */}
        <div ref={catalogRef} className="scroll-mt-6">
          <CategoryFilter
            activeCategory={activeCategory}
            onSelectCategory={setActiveCategory}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            inStockOnly={inStockOnly}
            onToggleInStock={setInStockOnly}
            counts={categoryCounts}
          />
        </div>

        {/* Products Grid Section */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          {/* Section Heading */}
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
                {activeCategory === 'all' && 'All Subscriptions & Plans'}
                {activeCategory === 'streaming' && 'Streaming Platforms'}
                {activeCategory === 'vpn' && 'VPN Services'}
                {activeCategory === 'productivity' && 'More / Productivity Services'}
                {activeCategory === 'por' && 'Price on Request Services'}
                <span className="text-xs font-bold text-slate-500 bg-slate-200 px-2 py-0.5 rounded-full">
                  {filteredServices.length}
                </span>
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Select quantities to automatically apply bulk discounts or order directly via WhatsApp.
              </p>
            </div>
          </div>

          {/* Empty Search Results */}
          {filteredServices.length === 0 ? (
            <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center max-w-lg mx-auto my-8 space-y-3">
              <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 mx-auto">
                <Info className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-slate-800">No matching subscriptions found</h3>
              <p className="text-xs text-slate-500">
                Try searching for another term like "Netflix", "NordVPN", "CapCut", "YouTube", or clear filters.
              </p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setActiveCategory('all');
                  setInStockOnly(false);
                }}
                className="mt-2 px-4 py-2 rounded-xl bg-blue-600 text-white font-bold text-xs hover:bg-blue-700 transition-colors cursor-pointer"
              >
                Reset All Filters
              </button>
            </div>
          ) : (
            /* Cards Grid Layout: 2 items per row on mobile (side-by-side), responsive scaling */
            <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-5">
              {filteredServices.map((service) => (
                <ServiceCard
                  key={service.id}
                  service={service}
                  onAddToCart={handleAddToCart}
                  onDirectOrder={(srv, qty) => {
                    handleAddToCart(srv, qty);
                    setIsCartOpen(true);
                  }}
                />
              ))}
            </div>
          )}
        </section>

        {/* Trust & Guarantee Section */}
        <TrustBadges />

        {/* FAQ Accordion Section */}
        <FAQSection />
      </main>

      {/* Floating WhatsApp Action Button */}
      <a
        href={whatsappGeneralUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-40 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold p-3.5 sm:px-5 sm:py-3 rounded-full shadow-2xl flex items-center gap-2 transition-all hover:scale-105 active:scale-95 group border border-emerald-300"
        aria-label="Contact Al Qaswa Digital Store on WhatsApp"
      >
        <MessageSquare className="w-6 h-6 fill-slate-950" />
        <span className="hidden sm:inline text-sm font-black">
          Order on WhatsApp ({WHATSAPP_DISPLAY})
        </span>
      </a>

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
      />

      {/* Footer */}
      <Footer />
    </div>
  );
}
