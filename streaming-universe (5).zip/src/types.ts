export type CategoryType = 'all' | 'streaming' | 'vpn' | 'productivity' | 'por';

export interface ServiceItem {
  id: string;
  name: string;
  category: CategoryType;
  price: number; // 0 if price on request
  duration?: string;
  type?: string; // Private / Shared / Mobile / PC
  bulkPrice?: number;
  bulkMinQty?: number;
  stock: number; // 0 means Sold Out
  isPriceOnRequest?: boolean;
  badge?: string;
  description?: string;
  popular?: boolean;
}

export interface CartItem {
  service: ServiceItem;
  quantity: number;
}

export interface OrderCustomerInfo {
  name: string;
  phone: string;
  paymentMethod: 'easypaisa' | 'jazzcash' | 'bank' | 'other';
  notes?: string;
}
