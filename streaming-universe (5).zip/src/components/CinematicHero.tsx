import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Play, Pause, Maximize2, Minimize2, Volume2, VolumeX, Sparkles, Compass, ShieldCheck } from 'lucide-react';
import heroImage from '../assets/images/alqaswa_hero_3d_1790483337108.jpg';

interface CinematicHeroProps {
  onExploreClick?: () => void;
}

export const CinematicHero: React.FC<CinematicHeroProps> = ({ onExploreClick }) => {
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(true);
  const [mousePos, setMousePos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const ambientNodesRef = useRef<{ gain: GainNode | null; osc1: OscillatorNode | null; osc2: OscillatorNode | null }>({
    gain: null,
    osc1: null,
    osc2: null,
  });

  // Track mouse for subtle 3D camera parallax
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width - 0.5) * 2; // -1 to 1
    const y = ((e.clientY - rect.top) / rect.height - 0.5) * 2; // -1 to 1
    setMousePos({ x, y });
  };

  const handleMouseLeave = () => {
    setMousePos({ x: 0, y: 0 });
  };

  // Toggle ambient desert & tech sound synth (Web Audio API)
  const toggleSound = () => {
    if (isMuted) {
      try {
        const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        if (!audioCtxRef.current) {
          audioCtxRef.current = new AudioContextClass();
        }
        if (audioCtxRef.current.state === 'suspended') {
          audioCtxRef.current.resume();
        }

        const ctx = audioCtxRef.current;
        const masterGain = ctx.createGain();
        masterGain.gain.setValueAtTime(0.06, ctx.currentTime);
        masterGain.connect(ctx.destination);

        // Warm harmonic drone (golden sand aesthetic)
        const osc1 = ctx.createOscillator();
        osc1.type = 'sine';
        osc1.frequency.setValueAtTime(108, ctx.currentTime); // Deep warm tone

        // Tech shimmer harmonic
        const osc2 = ctx.createOscillator();
        osc2.type = 'triangle';
        osc2.frequency.setValueAtTime(324, ctx.currentTime);

        const filter = ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(450, ctx.currentTime);

        osc1.connect(filter);
        osc2.connect(filter);
        filter.connect(masterGain);

        osc1.start();
        osc2.start();

        ambientNodesRef.current = { gain: masterGain, osc1, osc2 };
        setIsMuted(false);
      } catch (err) {
        console.warn('Audio not supported or blocked:', err);
      }
    } else {
      if (ambientNodesRef.current.gain && audioCtxRef.current) {
        ambientNodesRef.current.gain.gain.linearRampToValueAtTime(0.001, audioCtxRef.current.currentTime + 0.3);
        setTimeout(() => {
          try {
            ambientNodesRef.current.osc1?.stop();
            ambientNodesRef.current.osc2?.stop();
            ambientNodesRef.current.osc1?.disconnect();
            ambientNodesRef.current.osc2?.disconnect();
          } catch {
            // ignore
          }
        }, 350);
      }
      setIsMuted(true);
    }
  };

  useEffect(() => {
    return () => {
      try {
        ambientNodesRef.current.osc1?.stop();
        ambientNodesRef.current.osc2?.stop();
        audioCtxRef.current?.close();
      } catch {
        // cleanup ignore
      }
    };
  }, []);

  // HTML5 Canvas for dynamic 3D Particle Sand Ripples & Orbital Energy Field
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let angle = 0;

    // Responsive sizing
    const resizeCanvas = () => {
      if (!canvas) return;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = canvas.parentElement?.clientWidth ? canvas.parentElement.clientWidth * dpr : 1280 * dpr;
      canvas.height = canvas.parentElement?.clientHeight ? canvas.parentElement.clientHeight * dpr : 540 * dpr;
      ctx.scale(dpr, dpr);
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Particle generator
    const particleCount = 75;
    const particles = Array.from({ length: particleCount }, () => ({
      x: Math.random(),
      y: Math.random(),
      size: Math.random() * 2.2 + 0.8,
      speedY: Math.random() * 0.0012 + 0.0004,
      speedX: (Math.random() - 0.5) * 0.0006,
      opacity: Math.random() * 0.7 + 0.2,
      isGold: Math.random() > 0.45,
      pulse: Math.random() * Math.PI,
    }));

    const render = () => {
      if (!canvas) return;
      const width = canvas.width / (Math.min(window.devicePixelRatio || 1, 2));
      const height = canvas.height / (Math.min(window.devicePixelRatio || 1, 2));

      ctx.clearRect(0, 0, width, height);

      if (isPlaying) {
        angle += 0.012; // orbit speed
      }

      const centerX = width / 2;
      const centerY = height * 0.52;
      const radiusX = Math.min(width * 0.38, 380);
      const radiusY = Math.min(height * 0.26, 110);

      // 1. Draw Ground Sand Ripples with glowing tech lines
      const rippleCount = 6;
      for (let i = 0; i < rippleCount; i++) {
        const rFactor = 0.5 + i * 0.14;
        const currentRadiusX = radiusX * rFactor;
        const currentRadiusY = radiusY * rFactor;
        
        ctx.beginPath();
        ctx.ellipse(centerX, centerY + 20, currentRadiusX, currentRadiusY, 0, 0, Math.PI * 2);
        
        // Gradient for sand ripple edge
        const rippleGrad = ctx.createLinearGradient(centerX - currentRadiusX, centerY, centerX + currentRadiusX, centerY);
        if (i % 2 === 0) {
          rippleGrad.addColorStop(0, 'rgba(234, 179, 8, 0)');
          rippleGrad.addColorStop(0.3, 'rgba(234, 179, 8, 0.15)');
          rippleGrad.addColorStop(0.5, 'rgba(56, 189, 248, 0.35)');
          rippleGrad.addColorStop(0.7, 'rgba(234, 179, 8, 0.15)');
          rippleGrad.addColorStop(1, 'rgba(234, 179, 8, 0)');
        } else {
          rippleGrad.addColorStop(0, 'rgba(14, 165, 233, 0)');
          rippleGrad.addColorStop(0.5, 'rgba(14, 165, 233, 0.22)');
          rippleGrad.addColorStop(1, 'rgba(14, 165, 233, 0)');
        }
        
        ctx.strokeStyle = rippleGrad;
        ctx.lineWidth = i === 1 ? 1.8 : 1.1;
        if (i % 2 === 1) {
          ctx.setLineDash([8, 12]);
        } else {
          ctx.setLineDash([]);
        }
        ctx.stroke();
      }

      // 2. Continuous Circular Orbit Path for the Majestic Camel
      ctx.beginPath();
      ctx.ellipse(centerX, centerY + 20, radiusX * 0.95, radiusY * 0.95, 0, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(250, 204, 21, 0.4)';
      ctx.lineWidth = 1.4;
      ctx.setLineDash([4, 6]);
      ctx.stroke();
      ctx.setLineDash([]);

      // 3. Orbiting Camel Position Calculation (3D perspective circle)
      const camelOrbitAngle = angle;
      const camelX = centerX + Math.cos(camelOrbitAngle) * (radiusX * 0.95);
      const camelY = centerY + 20 + Math.sin(camelOrbitAngle) * (radiusY * 0.95);
      
      // Calculate depth scale (closer when at bottom of ellipse, farther when at top)
      const depthFactor = (Math.sin(camelOrbitAngle) + 1) / 2; // 0 (back) to 1 (front)
      const camelScale = 0.75 + depthFactor * 0.55; // 0.75 to 1.3
      const camelAlpha = 0.55 + depthFactor * 0.45; // 0.55 to 1.0

      // Glowing Ground contact footprint dust & tech flare
      const footGlow = ctx.createRadialGradient(camelX, camelY + 14 * camelScale, 2, camelX, camelY + 14 * camelScale, 38 * camelScale);
      footGlow.addColorStop(0, `rgba(56, 189, 248, ${0.8 * camelAlpha})`);
      footGlow.addColorStop(0.4, `rgba(234, 179, 8, ${0.5 * camelAlpha})`);
      footGlow.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = footGlow;
      ctx.beginPath();
      ctx.ellipse(camelX, camelY + 14 * camelScale, 38 * camelScale, 14 * camelScale, 0, 0, Math.PI * 2);
      ctx.fill();

      // Render Majestic Camel Silhouette & Glowing Tech Glyphs
      ctx.save();
      ctx.translate(camelX, camelY);
      ctx.scale(camelScale * (Math.cos(camelOrbitAngle) > 0 ? 1 : -1), camelScale); // Flip facing direction along orbit

      // Tech Aura around camel
      const aura = ctx.createRadialGradient(0, -10, 5, 0, -10, 40);
      aura.addColorStop(0, `rgba(253, 224, 71, ${0.45 * camelAlpha})`);
      aura.addColorStop(0.6, `rgba(14, 165, 233, ${0.25 * camelAlpha})`);
      aura.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = aura;
      ctx.beginPath();
      ctx.arc(0, -10, 40, 0, Math.PI * 2);
      ctx.fill();

      // Camel Body SVG Vector drawing on Canvas with golden & cyber-blue gradient
      const camelGrad = ctx.createLinearGradient(-25, -35, 25, 15);
      camelGrad.addColorStop(0, `rgba(255, 245, 180, ${camelAlpha})`);
      camelGrad.addColorStop(0.5, `rgba(234, 179, 8, ${camelAlpha})`);
      camelGrad.addColorStop(1, `rgba(14, 165, 233, ${0.85 * camelAlpha})`);

      ctx.fillStyle = camelGrad;
      ctx.strokeStyle = `rgba(255, 255, 255, ${0.7 * camelAlpha})`;
      ctx.lineWidth = 1.2;

      // Stylized majestic Arabian Camel Path
      ctx.beginPath();
      // Head & Neck
      ctx.moveTo(18, -32);
      ctx.bezierCurveTo(22, -35, 26, -33, 26, -28); // ears/muzzle
      ctx.bezierCurveTo(24, -24, 20, -23, 17, -22); // chin
      ctx.bezierCurveTo(15, -14, 12, -6, 9, -2);    // neck down to chest
      // Front Legs
      ctx.lineTo(8, 14);
      ctx.lineTo(5, 14);
      ctx.lineTo(5, 0);
      ctx.lineTo(2, 14);
      ctx.lineTo(-1, 14);
      ctx.lineTo(1, 0);
      // Underbelly
      ctx.bezierCurveTo(-4, 0, -10, -1, -14, 0);
      // Back Legs
      ctx.lineTo(-15, 14);
      ctx.lineTo(-18, 14);
      ctx.lineTo(-16, -2);
      ctx.lineTo(-19, 14);
      ctx.lineTo(-22, 14);
      // Rump & Tail
      ctx.lineTo(-22, -8);
      ctx.bezierCurveTo(-24, -5, -23, 2, -22, 4); // tail
      ctx.bezierCurveTo(-23, -12, -20, -16, -17, -18);
      // Majestic Hump
      ctx.bezierCurveTo(-14, -28, -6, -30, -2, -18); // hump crest
      // Saddle ornament & neck top
      ctx.bezierCurveTo(4, -18, 10, -22, 14, -28);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      // Royal saddle carpet & decorative tassel
      ctx.beginPath();
      ctx.ellipse(-7, -17, 7, 5, 0.2, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(56, 189, 248, ${0.9 * camelAlpha})`;
      ctx.fill();

      // Subtle tech ring around camel orbit anchor
      ctx.beginPath();
      ctx.arc(0, -10, 16, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(56, 189, 248, ${0.4 * camelAlpha})`;
      ctx.lineWidth = 1;
      ctx.stroke();

      ctx.restore();

      // 4. Draw Rising Desert Particle Dust & Digital Tech Sparks
      for (const p of particles) {
        if (isPlaying) {
          p.y -= p.speedY;
          p.x += p.speedX;
          p.pulse += 0.03;
          if (p.y < 0) {
            p.y = 1;
            p.x = Math.random();
          }
        }

        const px = p.x * width;
        const py = p.y * height;
        const currentAlpha = (Math.sin(p.pulse) * 0.3 + 0.7) * p.opacity;

        ctx.beginPath();
        ctx.arc(px, py, p.size, 0, Math.PI * 2);
        if (p.isGold) {
          ctx.fillStyle = `rgba(250, 204, 21, ${currentAlpha * 0.8})`;
          ctx.shadowColor = 'rgba(234, 179, 8, 0.6)';
        } else {
          ctx.fillStyle = `rgba(56, 189, 248, ${currentAlpha * 0.9})`;
          ctx.shadowColor = 'rgba(14, 165, 233, 0.8)';
        }
        ctx.shadowBlur = 6;
        ctx.fill();
        ctx.shadowBlur = 0; // reset
      }

      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', resizeCanvas);
    };
  }, [isPlaying]);

  return (
    <div
      ref={containerRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className={`relative overflow-hidden transition-all duration-500 bg-slate-950 border-b border-slate-800 ${
        isFullscreen
          ? 'fixed inset-0 z-50 h-screen w-screen flex flex-col justify-center'
          : 'w-full my-0 py-8 sm:py-12 md:py-14'
      }`}
      style={{
        perspective: '1200px',
      }}
    >
      {/* Background Cinematic Visual & Glow Mesh */}
      <div
        className="absolute inset-0 z-0 pointer-events-none transition-transform duration-700 ease-out will-change-transform"
        style={{
          transform: `scale(1.04) translate(${mousePos.x * -10}px, ${mousePos.y * -8}px)`,
        }}
      >
        <img
          src={heroImage}
          alt="Al Qaswa Digital Store 3D Cinematic Atmosphere"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center opacity-45 mix-blend-screen filter contrast-125 brightness-95"
        />
        {/* Volumetric Studio Lighting Gradients */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/70 to-slate-950/90" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(14,165,233,0.18),rgba(234,179,8,0.12),transparent_75%)]" />
        <div className="absolute top-0 inset-x-0 h-28 bg-gradient-to-b from-slate-950 to-transparent" />
        <div className="absolute bottom-0 inset-x-0 h-28 bg-gradient-to-t from-slate-950 to-transparent" />
      </div>

      {/* Interactive HTML5 Canvas Layer (Sand Ripples, Particles, 360 Camel Orbit) */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 z-10 w-full h-full pointer-events-none"
      />

      {/* Top Banner Control Pills (Resolution, Play/Pause, Sound, Fullscreen) */}
      <div className="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-bold tracking-wide uppercase bg-slate-900/90 text-amber-300 border border-amber-500/30 backdrop-blur-md shadow-sm">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
            <span>4K 3D Cinematic Animation</span>
          </span>
          <span className="hidden sm:inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-semibold text-cyan-300 bg-cyan-950/70 border border-cyan-800/50 backdrop-blur-md">
            <Compass className="w-3 h-3 text-cyan-400" />
            Seamless Orbit Loop
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Sound ambient toggle */}
          <button
            onClick={toggleSound}
            title={isMuted ? 'Turn on ambient sound' : 'Mute ambient sound'}
            className="p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-amber-300 border border-slate-700/60 backdrop-blur-md transition-all cursor-pointer shadow-sm active:scale-95"
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-amber-400" />}
          </button>

          {/* Loop Play / Pause */}
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            title={isPlaying ? 'Pause 3D orbit' : 'Play 3D orbit'}
            className="p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-cyan-300 border border-slate-700/60 backdrop-blur-md transition-all cursor-pointer shadow-sm active:scale-95"
          >
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-cyan-400 text-cyan-400" />}
          </button>

          {/* Fullscreen Expand */}
          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            title={isFullscreen ? 'Exit Fullscreen' : 'View Fullscreen Cinema'}
            className="p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/60 backdrop-blur-md transition-all cursor-pointer shadow-sm active:scale-95"
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Main Center Stage: Clean Modern Digital Branding Typography */}
      <div
        className="relative z-20 max-w-4xl mx-auto px-4 text-center flex flex-col items-center justify-center transition-transform duration-500 ease-out"
        style={{
          transform: `rotateX(${mousePos.y * -6}deg) rotateY(${mousePos.x * 8}deg)`,
        }}
      >
        {/* Emblem Motif */}
        <div className="inline-flex items-center justify-center w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-gradient-to-br from-amber-500/20 via-slate-900 to-cyan-500/20 border border-amber-400/40 p-2.5 shadow-[0_0_35px_rgba(234,179,8,0.25)] mb-4 sm:mb-5 backdrop-blur-md">
          {/* Stylized Golden Camel Emblem */}
          <svg
            viewBox="0 0 64 64"
            className="w-full h-full text-amber-300 filter drop-shadow-[0_0_8px_rgba(250,204,21,0.6)]"
            fill="currentColor"
          >
            <path d="M50 16c2.5-3 5-1.5 5 2s-3 4-5 4c-1.5 6-3 12-6 16l4 18h-4l-3-14h-3l-2 14h-4l1-14c-4 1-8 0-11-2l-4 16h-4l3-18c-3-2-5-6-5-10 0-2 2-2 3-1 2 2 4 1 6-2 3-5 8-8 12-3 3-5 7-8 11-10 1-5 4-8 6-9z" />
          </svg>
        </div>

        {/* Clean, Modern Digital Branding Text */}
        <h1 className="text-3xl sm:text-5xl md:text-6xl font-black tracking-tight text-white uppercase drop-shadow-xl">
          <span className="bg-gradient-to-r from-amber-200 via-yellow-300 to-amber-400 bg-clip-text text-transparent font-serif italic tracking-normal mr-2">
            Al Qaswa
          </span>{' '}
          <span className="bg-gradient-to-r from-cyan-300 via-sky-400 to-blue-500 bg-clip-text text-transparent font-sans tracking-tight">
            Digital Store
          </span>
        </h1>

        {/* Subtitle */}
        <p className="mt-2.5 sm:mt-3 text-sm sm:text-lg md:text-xl font-medium tracking-wide text-slate-300/95 max-w-2xl flex items-center justify-center gap-2 flex-wrap drop-shadow-md">
          <span className="text-cyan-400 font-semibold">Digital Store</span> of premium subscriptions
          <span className="hidden sm:inline text-amber-400/60">•</span>
          <span className="text-xs sm:text-sm font-semibold text-amber-300 bg-amber-950/60 px-2.5 py-0.5 rounded-full border border-amber-400/30">
            Instant Delivery & Bulk Discounts
          </span>
        </p>

        {/* Quick Highlights / Arab heritage meets high-tech digital store */}
        <div className="mt-6 flex flex-wrap items-center justify-center gap-3 sm:gap-4 text-xs font-semibold text-slate-300">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900/80 border border-slate-700/70 backdrop-blur-md">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Majestic Camel Orbit</span>
          </div>
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900/80 border border-slate-700/70 backdrop-blur-md">
            <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
            <span>100% Genuine Subscriptions</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="mt-7 flex items-center gap-3">
          <button
            onClick={() => {
              if (isFullscreen) setIsFullscreen(false);
              if (onExploreClick) {
                onExploreClick();
              } else {
                window.scrollTo({ top: 580, behavior: 'smooth' });
              }
            }}
            className="px-6 py-2.5 sm:px-8 sm:py-3 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-xs sm:text-sm shadow-[0_0_25px_rgba(6,182,212,0.4)] transition-all hover:scale-105 active:scale-95 cursor-pointer flex items-center gap-2"
          >
            <span>Explore Subscriptions</span>
            <span className="text-base leading-none">↓</span>
          </button>

          <a
            href="https://wa.me/923287042079?text=Hi%20Al%20Qaswa%20Digital%20Store!%20I%20would%20like%20to%20order%20a%20subscription."
            target="_blank"
            rel="noopener noreferrer"
            className="px-5 py-2.5 sm:px-6 sm:py-3 rounded-2xl bg-slate-900/90 hover:bg-slate-800 text-amber-300 hover:text-white font-bold text-xs sm:text-sm border border-amber-500/40 backdrop-blur-md transition-all hover:scale-105 active:scale-95 cursor-pointer flex items-center gap-2"
          >
            <span>Direct WhatsApp</span>
          </a>
        </div>
      </div>

      {/* Bottom Accent Line: Golden desert gradient transitioning to cyber blue */}
      <div className="absolute bottom-0 inset-x-0 h-[2px] bg-gradient-to-r from-transparent via-amber-400/80 to-transparent" />
    </div>
  );
};
