import React, { useState } from 'react';
import { MessageSquare, Sparkles, ChevronUp, ChevronDown } from 'lucide-react';
import { ServiceItem } from '../types';
import { WHATSAPP_NUMBER } from '../data/services';
import { ServiceLogo } from './ServiceLogo';

interface ServiceCardProps {
  service: ServiceItem;
  onAddToCart: (service: ServiceItem, quantity: number) => void;
  onDirectOrder: (service: ServiceItem, quantity: number) => void;
}

export const ServiceCard: React.FC<ServiceCardProps> = ({
  service,
  onAddToCart,
  onDirectOrder,
}) => {
  const [quantity, setQuantity] = useState<number>(1);
  const [added, setAdded] = useState<boolean>(false);

  const isSoldOut = service.stock === 0;

  const handleIncrement = () => {
    if (isSoldOut) return;
    setQuantity((prev) => Math.min(prev + 1, Math.max(service.stock, 10)));
  };

  const handleDecrement = () => {
    if (isSoldOut) return;
    setQuantity((prev) => Math.max(prev - 1, 1));
  };

  const handleAdd = () => {
    if (isSoldOut) return;
    onAddToCart(service, quantity);
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  };

  const handleWhatsAppQuickOrder = () => {
    const itemPrice = service.bulkPrice && quantity >= (service.bulkMinQty || 2)
      ? service.bulkPrice
      : service.price;
    
    const totalPrice = service.isPriceOnRequest ? 'Price on Request' : `Rs. ${(itemPrice * quantity).toLocaleString()}`;
    
    const msg = `Hi Al Qaswa Digital Store! I want to order:\n\n` +
      `📦 *${service.name}*\n` +
      `*Type/Duration:* ${service.duration || 'Standard'} ${service.type ? `(${service.type})` : ''}\n` +
      `*Quantity:* ${quantity}\n` +
      `*Estimated Price:* ${totalPrice}\n\n` +
      `Please provide payment details (Easypaisa/JazzCash/Bank) and instant activation.`;

    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`, '_blank');
  };

  // Check if bulk pricing applies for current selected quantity
  const isBulkActive = service.bulkPrice && quantity >= (service.bulkMinQty || 2);
  const effectivePrice = isBulkActive ? service.bulkPrice! : service.price;

  return (
    <div
      className={`relative bg-white border rounded-2xl p-3 sm:p-5 flex flex-col justify-between transition-all duration-200 ${
        isSoldOut
          ? 'border-slate-200 opacity-80 bg-slate-50/50'
          : 'border-slate-200/90 hover:border-blue-300 shadow-xs hover:shadow-md'
      }`}
    >
      {/* Popular or Feature Badge */}
      {service.popular && !isSoldOut && (
        <span className="absolute -top-2.5 right-3 sm:right-4 px-2 py-0.5 rounded-full text-[9px] sm:text-[10px] font-bold tracking-wider uppercase bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-xs flex items-center gap-1">
          <Sparkles className="w-2.5 h-2.5 sm:w-3 sm:h-3" /> Popular
        </span>
      )}

      <div>
        {/* Header with Logo & Title */}
        <div className="flex items-start gap-2.5 sm:gap-3 mb-2.5 sm:mb-3">
          <ServiceLogo serviceId={service.id} serviceName={service.name} className="w-10 h-10 sm:w-12 sm:h-12 shrink-0" />
          <div className="flex-1 min-w-0">
            <h3 className="text-sm sm:text-lg font-bold text-slate-900 leading-tight tracking-tight line-clamp-2">
              {service.name}
            </h3>
            {service.duration && (
              <span className="text-[10px] sm:text-[11px] font-semibold text-slate-500 bg-slate-100 px-1.5 sm:px-2 py-0.5 rounded-md inline-block mt-0.5">
                {service.duration} {service.type ? `• ${service.type}` : ''}
              </span>
            )}
          </div>
        </div>

        {/* Price Row */}
        <div className="mb-1.5 sm:mb-2">
          {service.isPriceOnRequest ? (
            <div className="text-sm sm:text-lg font-extrabold text-blue-600">Price on Request</div>
          ) : (
            <div className="flex flex-wrap items-baseline gap-1 sm:gap-2">
              <span className={`text-lg sm:text-2xl font-black ${isSoldOut ? 'text-slate-400' : 'text-amber-600 font-sans'}`}>
                Rs. {effectivePrice.toLocaleString()}
              </span>
              {isBulkActive && (
                <span className="text-[10px] sm:text-xs font-semibold text-emerald-600 bg-emerald-50 px-1 py-0.5 rounded-md border border-emerald-200">
                  Bulk Applied!
                </span>
              )}
            </div>
          )}
        </div>

        {/* Bulk Discount Pill */}
        {service.bulkPrice && service.bulkMinQty && (
          <div className="mb-3">
            <span className="inline-flex items-center text-xs font-semibold text-amber-900 bg-amber-100/80 border border-amber-200/80 px-2.5 py-1 rounded-lg">
              Bulk: Rs. {service.bulkPrice.toLocaleString()} (Min {service.bulkMinQty})
            </span>
          </div>
        )}

        {/* Stock Status Indicator */}
        <div className="mb-3">
          {isSoldOut ? (
            <span className="inline-flex items-center text-xs font-medium text-slate-500 bg-slate-200/80 px-2 py-0.5 rounded-md">
              Sold Out
            </span>
          ) : service.stock === 1 ? (
            <span className="text-xs font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200 animate-pulse">
              Only 1 left!
            </span>
          ) : (
            <span className="text-xs font-medium text-slate-500">
              {service.stock} in stock
            </span>
          )}
        </div>


      </div>

      {/* Bottom Controls Area (QTY + Order Actions) */}
      <div className="pt-2 border-t border-slate-100 mt-2">
        {service.isPriceOnRequest ? (
          <button
            onClick={handleWhatsAppQuickOrder}
            className="w-full py-2 sm:py-2.5 px-3 sm:px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm transition-all flex items-center justify-center gap-1.5 shadow-xs cursor-pointer active:scale-98"
          >
            <MessageSquare className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            <span>Inquire Price</span>
          </button>
        ) : (
          <div className="flex items-end gap-2 sm:gap-3">
            {/* QTY Control Box */}
            <div className="flex flex-col gap-0.5 sm:gap-1 shrink-0">
              <span className="text-[10px] sm:text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                QTY
              </span>
              <div className="flex items-center border border-slate-300 rounded-lg bg-slate-50/80 overflow-hidden w-16 sm:w-20">
                <input
                  type="number"
                  min={1}
                  max={service.stock || 1}
                  value={quantity}
                  disabled={isSoldOut}
                  onChange={(e) => {
                    const val = parseInt(e.target.value) || 1;
                    setQuantity(Math.max(1, Math.min(val, service.stock || 10)));
                  }}
                  className="w-8 sm:w-11 text-center font-bold text-slate-800 text-xs sm:text-sm bg-transparent py-1 focus:outline-none"
                />
                <div className="flex flex-col border-l border-slate-300 bg-white">
                  <button
                    type="button"
                    onClick={handleIncrement}
                    disabled={isSoldOut}
                    className="px-1 py-0.5 text-slate-600 hover:bg-slate-100 disabled:opacity-30 cursor-pointer"
                  >
                    <ChevronUp className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                  </button>
                  <button
                    type="button"
                    onClick={handleDecrement}
                    disabled={isSoldOut || quantity <= 1}
                    className="px-1 py-0.5 text-slate-600 hover:bg-slate-100 disabled:opacity-30 cursor-pointer border-t border-slate-200"
                  >
                    <ChevronDown className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                  </button>
                </div>
              </div>
            </div>

            {/* Order Button shifted directly next to QTY selector */}
            <div className="flex-1">
              {isSoldOut ? (
                <button
                  disabled
                  className="w-full py-2 sm:py-2.5 px-2 sm:px-4 rounded-xl bg-slate-200 text-slate-500 font-semibold text-xs sm:text-sm cursor-not-allowed"
                >
                  Sold Out
                </button>
              ) : (
                <button
                  onClick={handleWhatsAppQuickOrder}
                  className="w-full py-2 sm:py-2.5 px-3 sm:px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm transition-all shadow-xs flex items-center justify-center gap-1.5 cursor-pointer active:scale-98"
                >
                  Order
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
