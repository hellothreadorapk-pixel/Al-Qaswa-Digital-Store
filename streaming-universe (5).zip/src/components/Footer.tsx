import React from 'react';
import { Sparkles, MessageSquare, Phone, Shield, Heart } from 'lucide-react';
import { WHATSAPP_DISPLAY, WHATSAPP_NUMBER } from '../data/services';

export const Footer: React.FC = () => {
  const whatsappUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(
    'Hi Al Qaswa Digital Store! I want to inquire about subscriptions.'
  )}`;

  return (
    <footer className="bg-slate-950 text-slate-400 text-xs border-t border-slate-800 pt-12 pb-8 px-4 sm:px-6 lg:px-8 mt-16">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
        {/* Brand Col */}
        <div className="space-y-3 md:col-span-1">
          <div>
            <h3 className="text-xl font-black text-white tracking-tight">
              Al Qaswa <span className="text-blue-500">Digital Store</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Premium subscriptions • Managed by <span className="text-blue-400 font-semibold">QasimAzeem</span>
            </p>
          </div>
          <p className="text-slate-400 text-xs leading-relaxed">
            Your trusted store for premium subscription platforms, VPN services, AI tools, and productivity applications with 100% genuine warranty and instant WhatsApp activation.
          </p>
          <div className="flex items-center gap-2 pt-1 text-emerald-400 font-semibold text-xs">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            WhatsApp Support Available 24/7
          </div>
        </div>

        {/* Quick Links */}
        <div>
          <h4 className="text-sm font-bold text-white mb-3">Popular Categories</h4>
          <ul className="space-y-2 text-slate-400">
            <li><a href="#streaming" className="hover:text-white transition-colors">Streaming Platforms</a></li>
            <li><a href="#vpn" className="hover:text-white transition-colors">VPN Services</a></li>
            <li><a href="#productivity" className="hover:text-white transition-colors">Productivity & AI Tools</a></li>
            <li><a href="#por" className="hover:text-white transition-colors">Price on Request</a></li>
          </ul>
        </div>

        {/* Payment Methods */}
        <div>
          <h4 className="text-sm font-bold text-white mb-3">Supported Payment Methods</h4>
          <div className="space-y-2">
            <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 flex items-center gap-2 text-slate-300">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              Easypaisa Mobile Account
            </div>
            <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 flex items-center gap-2 text-slate-300">
              <span className="w-2 h-2 rounded-full bg-red-500"></span>
              JazzCash Mobile Wallet
            </div>
            <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 flex items-center gap-2 text-slate-300">
              <span className="w-2 h-2 rounded-full bg-blue-500"></span>
              All Major Bank Transfers (Pakistan)
            </div>
          </div>
        </div>

        {/* Contact info */}
        <div>
          <h4 className="text-sm font-bold text-white mb-3">Official Contact</h4>
          <div className="space-y-2.5">
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-emerald-400 hover:text-emerald-300 font-bold text-sm bg-emerald-950/60 border border-emerald-800/50 p-2.5 rounded-xl transition-all"
            >
              <Phone className="w-4 h-4" />
              WhatsApp: {WHATSAPP_DISPLAY}
            </a>
            <p className="text-[11px] text-slate-500">
              Operational Hours: 24 Hours / 7 Days a week. Fast response guaranteed.
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto pt-6 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-3 text-slate-500 text-[11px]">
        <p>© {new Date().getFullYear()} Al Qaswa Digital Store by <strong className="text-slate-300 font-semibold">QasimAzeem</strong>. All rights reserved.</p>
        <p className="flex items-center gap-1">
          Made with <Heart className="w-3 h-3 text-red-500 fill-red-500" /> for Premium Streaming Enthusiasts
        </p>
      </div>
    </footer>
  );
};
