import React from 'react';
import { ShoppingBag, MessageSquare } from 'lucide-react';
import { WHATSAPP_DISPLAY, WHATSAPP_NUMBER } from '../data/services';
import { BrandLogo } from './BrandLogo';

interface HeaderProps {
  cartCount: number;
  cartTotal: number;
  onOpenCart: () => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  cartCount,
  cartTotal,
  onOpenCart,
  searchQuery,
  onSearchChange,
}) => {
  const whatsappUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(
    'Hi Al Qaswa Digital Store! I need assistance regarding subscription plans.'
  )}`;

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      {/* Main Nav Header */}
      <div className="max-w-7xl mx-auto px-4 py-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-4">
          {/* Logo Brand in top corner */}
          <BrandLogo size="md" />

          {/* Right Header Actions: WhatsApp & Cart Button */}
          <div className="flex items-center gap-2 sm:gap-3">
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden sm:flex items-center gap-2 px-3.5 py-2 rounded-xl bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200 transition-all font-semibold text-sm"
            >
              <MessageSquare className="w-4 h-4 text-emerald-600" />
              <span>{WHATSAPP_DISPLAY}</span>
            </a>

            <button
              onClick={onOpenCart}
              className="relative flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm transition-all shadow-sm active:scale-95 cursor-pointer"
              aria-label="View Shopping Cart"
            >
              <ShoppingBag className="w-4 h-4" />
              <span className="hidden sm:inline">Cart</span>
              {cartCount > 0 && (
                <>
                  <span className="ml-0.5 px-1.5 py-0.5 text-xs font-bold rounded-full bg-amber-400 text-slate-900">
                    {cartCount}
                  </span>
                  <span className="hidden md:inline text-xs font-normal border-l border-blue-400 pl-2 ml-1 text-blue-100">
                    Rs. {cartTotal.toLocaleString()}
                  </span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
