import React from 'react';
import { Zap, ShieldCheck, Wallet, Clock, MessageCircle } from 'lucide-react';
import { WHATSAPP_DISPLAY, WHATSAPP_NUMBER } from '../data/services';

export const TrustBadges: React.FC = () => {
  const whatsappUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(
    'Hi Al Qaswa Digital Store! I have a question about delivery & payment.'
  )}`;

  return (
    <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-indigo-950 text-white py-10 px-4 sm:px-6 lg:px-8 my-10 rounded-3xl mx-4 sm:mx-6 lg:mx-8 shadow-xl">
      <div className="max-w-7xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-8">
          <span className="text-xs font-extrabold uppercase tracking-widest text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
            Why Choose Al Qaswa Digital Store
          </span>
          <h2 className="text-2xl sm:text-3xl font-black mt-2 text-white">
            Fast, Trusted & Guaranteed Premium Accounts
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 mt-2">
            Get instant activation, private screens, full warranty and 24/7 support directly on WhatsApp.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-slate-800/80 border border-slate-700/80 p-5 rounded-2xl flex flex-col items-center text-center">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center mb-3 border border-emerald-500/30">
              <Zap className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white mb-1">Instant Delivery</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Login details and credentials delivered straight to your WhatsApp within 5 to 15 minutes.
            </p>
          </div>

          <div className="bg-slate-800/80 border border-slate-700/80 p-5 rounded-2xl flex flex-col items-center text-center">
            <div className="w-12 h-12 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center mb-3 border border-blue-500/30">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white mb-1">Full Warranty</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              100% replacement warranty for the complete duration of your subscription plan.
            </p>
          </div>

          <div className="bg-slate-800/80 border border-slate-700/80 p-5 rounded-2xl flex flex-col items-center text-center">
            <div className="w-12 h-12 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center mb-3 border border-amber-500/30">
              <Wallet className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white mb-1">Easy Payments</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Pay securely via Easypaisa, JazzCash, or direct Bank Transfer in Pakistan.
            </p>
          </div>

          <div className="bg-slate-800/80 border border-slate-700/80 p-5 rounded-2xl flex flex-col items-center text-center">
            <div className="w-12 h-12 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center mb-3 border border-purple-500/30">
              <Clock className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white mb-1">24/7 WhatsApp Support</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Friendly support line active 24/7 on WhatsApp for setup help and renewal.
            </p>
          </div>
        </div>

        <div className="mt-8 pt-6 border-t border-slate-700/60 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div className="flex items-center gap-3">
            <MessageCircle className="w-6 h-6 text-emerald-400" />
            <div>
              <p className="text-xs font-semibold text-slate-300">Have custom requirements or bulk order inquiries?</p>
              <p className="text-sm font-bold text-white">Contact us directly on WhatsApp: {WHATSAPP_DISPLAY}</p>
            </div>
          </div>

          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold text-sm transition-all shadow-md flex items-center gap-2 cursor-pointer"
          >
            <MessageCircle className="w-4 h-4 fill-slate-950" />
            Chat on WhatsApp
          </a>
        </div>
      </div>
    </div>
  );
};
