import React, { useState } from 'react';
import { ChevronDown, HelpCircle, MessageCircle } from 'lucide-react';
import { WHATSAPP_DISPLAY, WHATSAPP_NUMBER } from '../data/services';

interface FAQItem {
  question: string;
  answer: string;
}

export const FAQSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs: FAQItem[] = [
    {
      question: 'How quickly will I receive my subscription after ordering?',
      answer:
        'Orders placed via WhatsApp are processed instantly! Once payment screenshot is sent (Easypaisa, JazzCash, or Bank Transfer), credentials or activation links are provided within 5 to 15 minutes.',
    },
    {
      question: 'Are these subscriptions private screen or shared?',
      answer:
        'We offer both Private Screen/Account and Shared options clearly labeled on each product card. Private Screen plans include your own personal profile with PIN protection.',
    },
    {
      question: 'What is your warranty and replacement policy?',
      answer:
        'All accounts come with 100% full replacement warranty for the complete period of your purchase. If you experience any technical glitch, our WhatsApp team issues immediate replacement.',
    },
    {
      question: 'How do bulk discounts work?',
      answer:
        'When ordering 2 or more quantities of eligible items (e.g., Netflix, CapCut, NordVPN, Prime Video), the discounted bulk price is automatically applied to your cart!',
    },
    {
      question: 'How can I order items listed under "Price on Request"?',
      answer:
        'Simply click the "Inquire Price on WhatsApp" button on items like Grok AI, Google Gemini Advanced, Veo 3, Canva Pro, or LinkedIn Premium to receive the latest promotional pricing immediately.',
    },
  ];

  return (
    <section className="py-12 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto my-6">
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 text-blue-700 text-xs font-bold border border-blue-200 mb-2">
          <HelpCircle className="w-3.5 h-3.5" />
          Got Questions?
        </div>
        <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
          Frequently Asked Questions
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Everything you need to know about ordering premium subscriptions on Al Qaswa Digital Store.
        </p>
      </div>

      <div className="space-y-3">
        {faqs.map((faq, idx) => {
          const isOpen = openIndex === idx;
          return (
            <div
              key={idx}
              className="border border-slate-200 rounded-2xl bg-white overflow-hidden transition-all shadow-2xs"
            >
              <button
                onClick={() => setOpenIndex(isOpen ? null : idx)}
                className="w-full p-4 sm:p-5 text-left flex items-center justify-between gap-4 font-bold text-slate-900 text-sm sm:text-base hover:bg-slate-50/80 transition-colors cursor-pointer"
              >
                <span>{faq.question}</span>
                <ChevronDown
                  className={`w-4 h-4 text-slate-400 transition-transform duration-200 shrink-0 ${
                    isOpen ? 'rotate-180 text-blue-600' : ''
                  }`}
                />
              </button>

              {isOpen && (
                <div className="px-4 pb-5 pt-0 sm:px-5 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100 bg-slate-50/40">
                  {faq.answer}
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="mt-8 text-center bg-blue-50/70 border border-blue-200 rounded-2xl p-4 sm:p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="text-left">
          <h3 className="text-sm font-bold text-slate-900">Still have questions?</h3>
          <p className="text-xs text-slate-600">Contact our customer care directly on WhatsApp</p>
        </div>
        <a
          href={`https://wa.me/${WHATSAPP_NUMBER}`}
          target="_blank"
          rel="noopener noreferrer"
          className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition-all flex items-center gap-2 cursor-pointer shadow-xs"
        >
          <MessageCircle className="w-4 h-4" />
          WhatsApp Support ({WHATSAPP_DISPLAY})
        </a>
      </div>
    </section>
  );
};
