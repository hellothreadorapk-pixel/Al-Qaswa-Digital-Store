import React from 'react';

interface BrandLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const BrandLogo: React.FC<BrandLogoProps> = () => {
  return (
    <div className="flex flex-col justify-center select-none">
      <span className="text-xl sm:text-2xl font-black tracking-tight text-slate-900 leading-none">
        Al Qaswa <span className="text-blue-600">Digital Store</span>
      </span>
      <span className="text-[11px] font-medium text-slate-500 mt-1 flex items-center gap-1.5 flex-wrap">
        <span>Digital Store of premium subscriptions</span>
        <span className="w-1 h-1 rounded-full bg-slate-300"></span>
        <span className="font-semibold text-blue-600 bg-blue-50 px-1.5 py-0.2 rounded-md border border-blue-200/60">QasimAzeem</span>
      </span>
    </div>
  );
};
