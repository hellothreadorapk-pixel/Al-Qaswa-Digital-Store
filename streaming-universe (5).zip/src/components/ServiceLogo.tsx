import React from 'react';

interface ServiceLogoProps {
  serviceId: string;
  serviceName: string;
  className?: string;
}

export const ServiceLogo: React.FC<ServiceLogoProps> = ({
  serviceId,
  serviceName,
  className = 'w-12 h-12',
}) => {
  const id = serviceId.toLowerCase();

  // 1. Netflix
  if (id.includes('netflix')) {
    return (
      <div className={`${className} rounded-2xl bg-black flex items-center justify-center p-2 shadow-sm border border-red-900/40 shrink-0`}>
        <svg viewBox="0 0 24 24" className="w-full h-full fill-[#E50914]">
          <path d="M5.398 0v24l4.577-1.127V13.882l5.047 10.118H19.6V0l-4.577 1.127v8.991L9.977 0H5.398z" />
        </svg>
      </div>
    );
  }

  // 2. Prime Video
  if (id.includes('prime')) {
    return (
      <div className={`${className} rounded-2xl bg-[#0F172A] flex items-center justify-center p-2 shadow-sm border border-sky-900/40 shrink-0`}>
        <svg viewBox="0 0 24 24" className="w-full h-full fill-[#00A8E1]">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l7 4.5-7 4.5z" />
          <path d="M6 18c3.5 2 8.5 2 12 0" stroke="#00A8E1" strokeWidth="2" strokeLinecap="round" fill="none" />
        </svg>
      </div>
    );
  }

  // 3. Disney+
  if (id.includes('disney')) {
    return (
      <div className={`${className} rounded-2xl bg-gradient-to-br from-[#113CCF] to-[#040B2D] flex items-center justify-center p-2 shadow-sm text-white font-black italic tracking-tighter shrink-0 border border-blue-400/30`}>
        <span className="text-xl font-serif">D+</span>
      </div>
    );
  }

  // 4. Crunchyroll
  if (id.includes('crunchyroll')) {
    return (
      <div className={`${className} rounded-2xl bg-[#FF6600] flex items-center justify-center p-2 shadow-sm shrink-0 border border-amber-300/40`}>
        <div className="w-6 h-6 rounded-full bg-white flex items-center justify-center">
          <div className="w-3.5 h-3.5 rounded-full bg-[#FF6600] ml-1"></div>
        </div>
      </div>
    );
  }

  // 5. Chaupal
  if (id.includes('chaupal')) {
    return (
      <div className={`${className} rounded-2xl bg-[#181818] flex items-center justify-center p-1.5 shadow-sm text-[#FFC107] font-black text-xs shrink-0 border border-amber-500/40`}>
        <span className="tracking-tighter uppercase font-black text-[11px] bg-[#FFC107] text-black px-1 py-0.5 rounded-md">
          CHAU
        </span>
      </div>
    );
  }

  // 6. HBO Max
  if (id.includes('hbo')) {
    return (
      <div className={`${className} rounded-2xl bg-[#5822B4] flex items-center justify-center p-1.5 shadow-sm text-white font-black tracking-widest text-xs shrink-0 border border-purple-400/40`}>
        <span className="text-sm font-extrabold tracking-tight">MAX</span>
      </div>
    );
  }

  // 7. ZEE5
  if (id.includes('zee5') || id.includes('zee')) {
    return (
      <div className={`${className} rounded-2xl bg-gradient-to-br from-[#821E88] to-[#420A47] flex items-center justify-center p-1.5 shadow-sm text-white font-black shrink-0 border border-pink-400/30`}>
        <span className="text-xs font-black tracking-tighter text-amber-300">ZEE5</span>
      </div>
    );
  }

  // 8. Apple TV+
  if (id.includes('apple')) {
    return (
      <div className={`${className} rounded-2xl bg-slate-950 flex items-center justify-center p-2 shadow-sm text-white shrink-0 border border-slate-700`}>
        <span className="text-xs font-bold tracking-tight text-slate-200">tv+</span>
      </div>
    );
  }

  // 9. IPTV Smarters
  if (id.includes('iptv')) {
    return (
      <div className={`${className} rounded-2xl bg-gradient-to-tr from-cyan-600 to-blue-600 flex items-center justify-center p-2 shadow-sm text-white shrink-0 border border-cyan-300/40`}>
        <span className="text-[10px] font-black tracking-widest uppercase">IPTV</span>
      </div>
    );
  }

  // 10. NordVPN
  if (id.includes('nord')) {
    return (
      <div className={`${className} rounded-2xl bg-[#4687FF] flex items-center justify-center p-2 shadow-sm text-white shrink-0 border border-blue-200/50`}>
        <svg viewBox="0 0 24 24" className="w-6 h-6 fill-white">
          <path d="M12 2L3 7v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-5.45 9-12V7l-9-5zm0 4.18l6 3.33v4.49c0 3.76-2.56 7.28-6 8.35-3.44-1.07-6-4.59-6-8.35V9.51l6-3.33z" />
        </svg>
      </div>
    );
  }

  // 11. Surfshark
  if (id.includes('surfshark')) {
    return (
      <div className={`${className} rounded-2xl bg-[#13B5EA] flex items-center justify-center p-2 shadow-sm text-white shrink-0 border border-cyan-200/50`}>
        <svg viewBox="0 0 24 24" className="w-6 h-6 fill-white">
          <path d="M12 2L2 7v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-5.45 9-12V7l-10-5zm0 18c-3.75-1-6.5-4.5-6.5-8.5V8.5L12 5l6.5 3.5V11.5c0 4-2.75 7.5-6.5 8.5z" />
        </svg>
      </div>
    );
  }

  // 12. Proton VPN
  if (id.includes('proton')) {
    return (
      <div className={`${className} rounded-2xl bg-[#6D4AFF] flex items-center justify-center p-2 shadow-sm text-white shrink-0 border border-purple-300/40`}>
        <span className="text-xs font-black tracking-tighter">PROTON</span>
      </div>
    );
  }

  // 13. PIA VPN
  if (id.includes('pia')) {
    return (
      <div className={`${className} rounded-2xl bg-[#00B140] flex items-center justify-center p-2 shadow-sm text-white shrink-0 border border-emerald-300/40`}>
        <span className="text-[11px] font-black tracking-widest">PIA</span>
      </div>
    );
  }

  // 14. ExpressVPN
  if (id.includes('express')) {
    return (
      <div className={`${className} rounded-2xl bg-[#EB1521] flex items-center justify-center p-2 shadow-sm text-white shrink-0 border border-red-300/40`}>
        <span className="text-xs font-black italic tracking-tighter">EXPRESS</span>
      </div>
    );
  }

  // 15. HMA VPN
  if (id.includes('hma')) {
    return (
      <div className={`${className} rounded-2xl bg-[#FFC629] flex items-center justify-center p-2 shadow-sm text-slate-900 shrink-0 border border-amber-400`}>
        <span className="text-xs font-black tracking-tight">HMA!</span>
      </div>
    );
  }

  // 16. CapCut
  if (id.includes('capcut')) {
    return (
      <div className={`${className} rounded-2xl bg-slate-950 flex items-center justify-center p-2 shadow-sm text-white shrink-0 border border-slate-800`}>
        <div className="w-6 h-6 border-2 border-white rounded-md flex items-center justify-center font-black text-xs">
          C
        </div>
      </div>
    );
  }

  // 17. QuillBot
  if (id.includes('quillbot')) {
    return (
      <div className={`${className} rounded-2xl bg-[#00A884] flex items-center justify-center p-2 shadow-sm text-white shrink-0 border border-emerald-300/40`}>
        <span className="text-xs font-extrabold tracking-tight">QUILL</span>
      </div>
    );
  }

  // 18. Grammarly
  if (id.includes('grammarly')) {
    return (
      <div className={`${className} rounded-2xl bg-[#15C39A] flex items-center justify-center p-2 shadow-sm text-white shrink-0 border border-emerald-300/40`}>
        <div className="w-6 h-6 rounded-full border-2 border-white flex items-center justify-center font-bold text-xs">
          g
        </div>
      </div>
    );
  }

  // 19. MS Office 365
  if (id.includes('office') || id.includes('ms-office')) {
    return (
      <div className={`${className} rounded-2xl bg-[#D83B01] flex items-center justify-center p-2 shadow-sm text-white shrink-0 border border-orange-300/40`}>
        <div className="grid grid-cols-2 gap-0.5 w-5 h-5">
          <div className="bg-white rounded-xs"></div>
          <div className="bg-white rounded-xs"></div>
          <div className="bg-white rounded-xs"></div>
          <div className="bg-white rounded-xs"></div>
        </div>
      </div>
    );
  }

  // 20. YouTube Premium
  if (id.includes('youtube')) {
    return (
      <div className={`${className} rounded-2xl bg-[#FF0000] flex items-center justify-center p-2 shadow-sm text-white shrink-0 border border-red-300/40`}>
        <svg viewBox="0 0 24 24" className="w-6 h-6 fill-white">
          <path d="M21.58 7.19a2.705 2.705 0 00-1.9-1.9C18.01 4.75 12 4.75 12 4.75s-6.01 0-7.68.54a2.705 2.705 0 00-1.9 1.9C1.88 8.86 1.88 12 1.88 12s0 3.14.54 4.81c.3.1.95 1.4 1.9 1.9 1.67.54 7.68.54 7.68.54s6.01 0 7.68-.54c.95-.5 1.6-1.8 1.9-1.9.54-1.67.54-4.81.54-4.81s0-3.14-.54-4.81zM10 15V9l5.2 3L10 15z" />
        </svg>
      </div>
    );
  }

  // 21. Grok AI
  if (id.includes('grok')) {
    return (
      <div className={`${className} rounded-2xl bg-black flex items-center justify-center p-2 shadow-sm text-white shrink-0 border border-slate-700`}>
        <span className="text-sm font-black tracking-widest font-mono">/grok</span>
      </div>
    );
  }

  // 21b. ChatGPT / OpenAI
  if (id.includes('chatgpt') || id.includes('gpt')) {
    return (
      <div className={`${className} rounded-2xl bg-[#10A37F] flex items-center justify-center p-2 shadow-sm text-white shrink-0 border border-emerald-300/40`}>
        <svg viewBox="0 0 24 24" className="w-6 h-6 fill-white">
          <path d="M22.2819 9.8211a5.9847 5.9847 0 0 0-.5157-4.9108 6.0462 6.0462 0 0 0-6.5098-2.9A6.0651 6.0651 0 0 0 4.9807 4.1818a5.9847 5.9847 0 0 0-3.9977 2.9 6.0462 6.0462 0 0 0 .7427 7.0966 5.98 5.98 0 0 0 .511 4.9107 6.051 6.051 0 0 0 6.5146 2.9001A5.9847 5.9847 0 0 0 13.2599 24a6.0557 6.0557 0 0 0 5.7718-4.2058 5.9894 5.9894 0 0 0 3.9977-2.9001 6.0557 6.0557 0 0 0-.7475-7.0729zm-9.022 12.6081a4.4755 4.4755 0 0 1-2.8764-1.0408l.1419-.0804 4.7783-2.7582a.7948.7948 0 0 0 .3927-.6813v-6.7369l2.02 1.1686a.071.071 0 0 1 .038.052v5.5826a4.504 4.504 0 0 1-4.4945 4.4944zm-9.6607-4.1254a4.4708 4.4708 0 0 1-.5346-3.0137l.142.0852 4.783 2.7582a.7712.7712 0 0 0 .7806 0l5.8428-3.3685v2.3324a.0804.0804 0 0 1-.0332.0615L9.74 19.9502a4.4992 4.4992 0 0 1-6.1408-1.6464zM2.3408 7.8956a4.485 4.485 0 0 1 2.3655-1.9728V11.6a.7664.7664 0 0 0 .3879.6765l5.8144 3.3543-2.0201 1.1685a.0757.0757 0 0 1-.071 0l-4.8303-2.7865A4.504 4.504 0 0 1 2.3408 7.8956zm16.0993 3.8558L12.5973 8.3829l2.02-1.1638a.0804.0804 0 0 1 .071 0l4.8303 2.7913a4.4944 4.4944 0 0 1-.6765 8.1042v-5.6772a.79.79 0 0 0-.402-.686zm2.0107-3.0231l-.142-.0852-4.7735-2.7818a.7759.7759 0 0 0-.7854 0L9.409 9.2297V6.8974a.0662.0662 0 0 1 .0284-.0615l4.8303-2.7866a4.4992 4.4992 0 0 1 6.6802 4.66zM8.3065 12.863l-2.02-1.1638a.0804.0804 0 0 1-.038-.0567V6.0742a4.4992 4.4992 0 0 1 7.3757-3.4537l-.142.0805L8.704 5.459a.7948.7948 0 0 0-.3927.6813v6.7227zm1.1458-1.9213l2.5477-1.472 2.5477 1.472v2.9392l-2.5477 1.472-2.5477-1.472z"/>
        </svg>
      </div>
    );
  }

  // 21c. Claude AI / Anthropic
  if (id.includes('claude')) {
    return (
      <div className={`${className} rounded-2xl bg-[#CC785C] flex items-center justify-center p-2 shadow-sm text-white shrink-0 border border-orange-300/40`}>
        <svg viewBox="0 0 24 24" className="w-6 h-6 fill-white">
          <path d="M12 2a1 1 0 0 1 1 1v6.586l4.657-4.657a1 1 0 1 1 1.414 1.414L14.414 11H21a1 1 0 1 1 0 2h-6.586l4.657 4.657a1 1 0 0 1-1.414 1.414L13 14.414V21a1 1 0 1 1-2 0v-6.586l-4.657 4.657a1 1 0 0 1-1.414-1.414L9.586 13H3a1 1 0 1 1 0-2h6.586L4.929 6.343a1 1 0 0 1 1.414-1.414L11 9.586V3a1 1 0 0 1 1-1z" />
        </svg>
      </div>
    );
  }

  // 22. Veo 3
  if (id.includes('veo')) {
    return (
      <div className={`${className} rounded-2xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-purple-600 flex items-center justify-center p-2 shadow-sm text-white shrink-0 border border-purple-300/40`}>
        <span className="text-xs font-black tracking-widest">VEO3</span>
      </div>
    );
  }

  // 23. Google Gemini
  if (id.includes('gemini')) {
    return (
      <div className={`${className} rounded-2xl bg-gradient-to-tr from-[#4285F4] via-[#9B51E0] to-[#E91E63] flex items-center justify-center p-2 shadow-sm text-white shrink-0 border border-purple-200/50`}>
        <svg viewBox="0 0 24 24" className="w-6 h-6 fill-white">
          <path d="M12 0C12 6.627 6.627 12 0 12c6.627 0 12 5.373 12 12 0-6.627 5.373-12 12-12-6.627 0-12-5.373-12-12z" />
        </svg>
      </div>
    );
  }

  // 24. Hotspot Shield
  if (id.includes('hotspot')) {
    return (
      <div className={`${className} rounded-2xl bg-[#FF3366] flex items-center justify-center p-2 shadow-sm text-white shrink-0 border border-red-300/40`}>
        <span className="text-[10px] font-black tracking-tighter">HOTSPOT</span>
      </div>
    );
  }

  // 24b. ElevenLabs
  if (id.includes('eleven')) {
    return (
      <div className={`${className} rounded-2xl bg-black flex items-center justify-center p-2 shadow-sm text-white shrink-0 border border-slate-700`}>
        <div className="flex items-center gap-1">
          <div className="w-1.5 h-5 bg-white rounded-full"></div>
          <div className="w-1.5 h-5 bg-white rounded-full"></div>
        </div>
      </div>
    );
  }

  // 25. Canva Pro
  if (id.includes('canva')) {
    return (
      <div className={`${className} rounded-2xl bg-gradient-to-tr from-[#00C4CC] to-[#7D2AE8] flex items-center justify-center p-2 shadow-sm text-white shrink-0 border border-cyan-200/50`}>
        <span className="text-sm font-serif italic font-bold">Canva</span>
      </div>
    );
  }

  // 26. LinkedIn Premium
  if (id.includes('linkedin')) {
    return (
      <div className={`${className} rounded-2xl bg-[#0077B5] flex items-center justify-center p-2 shadow-sm text-white shrink-0 border border-sky-300/50`}>
        <span className="text-sm font-black font-sans">in</span>
      </div>
    );
  }

  // 27. Discovery+
  if (id.includes('discovery')) {
    return (
      <div className={`${className} rounded-2xl bg-[#003057] flex items-center justify-center p-2 shadow-sm text-amber-400 font-extrabold text-xs shrink-0 border border-blue-400/30`}>
        <span>d+</span>
      </div>
    );
  }

  // 28. InVideo AI
  if (id.includes('invideo')) {
    return (
      <div className={`${className} rounded-2xl bg-[#7C3AED] flex items-center justify-center p-2 shadow-sm text-white shrink-0 border border-purple-300/40`}>
        <span className="text-[10px] font-black tracking-widest">INVIDEO</span>
      </div>
    );
  }

  // 29. Moz Pro
  if (id.includes('moz')) {
    return (
      <div className={`${className} rounded-2xl bg-[#00B2E3] flex items-center justify-center p-2 shadow-sm text-white shrink-0 border border-cyan-300/40`}>
        <span className="text-sm font-black">moz</span>
      </div>
    );
  }

  // 30. Udemy
  if (id.includes('udemy')) {
    return (
      <div className={`${className} rounded-2xl bg-[#A435F0] flex items-center justify-center p-2 shadow-sm text-white shrink-0 border border-purple-300/40`}>
        <span className="text-xs font-black">udemy</span>
      </div>
    );
  }

  // 31. Keepa
  if (id.includes('keepa')) {
    return (
      <div className={`${className} rounded-2xl bg-[#FF9900] flex items-center justify-center p-2 shadow-sm text-slate-950 shrink-0 border border-amber-300`}>
        <span className="text-xs font-black">keepa</span>
      </div>
    );
  }

  // Generic Fallback Badge
  return (
    <div className={`${className} rounded-2xl bg-gradient-to-tr from-slate-800 to-slate-900 text-blue-400 font-bold flex items-center justify-center shadow-xs border border-slate-700 shrink-0 text-xs`}>
      {serviceName.slice(0, 2).toUpperCase()}
    </div>
  );
};
