import React, { useState } from 'react';
import { X, Trash2, Plus, Minus, MessageSquare, ShoppingBag, CheckCircle, Shield, ArrowRight } from 'lucide-react';
import { CartItem, OrderCustomerInfo } from '../types';
import { WHATSAPP_NUMBER, WHATSAPP_DISPLAY } from '../data/services';
import { ServiceLogo } from './ServiceLogo';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (serviceId: string, quantity: number) => void;
  onRemoveItem: (serviceId: string) => void;
  onClearCart: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}) => {
  const [customerInfo, setCustomerInfo] = useState<OrderCustomerInfo>({
    name: '',
    phone: '',
    paymentMethod: 'easypaisa',
    notes: '',
  });

  const [orderSent, setOrderSent] = useState(false);

  if (!isOpen) return null;

  // Calculate cart total with bulk pricing check
  const calculatedItems = cartItems.map((item) => {
    const isBulk =
      item.service.bulkPrice &&
      item.quantity >= (item.service.bulkMinQty || 2);
    
    const unitPrice = isBulk ? item.service.bulkPrice! : item.service.price;
    const subtotal = unitPrice * item.quantity;

    return {
      ...item,
      isBulk,
      unitPrice,
      subtotal,
    };
  });

  const grandTotal = calculatedItems.reduce((acc, curr) => acc + curr.subtotal, 0);

  const handleSendOrder = (e: React.FormEvent) => {
    e.preventDefault();

    if (cartItems.length === 0) return;

    let messageText = `*AL QASWA DIGITAL STORE ORDER* 🛒\n`;
    messageText += `-----------------------------------\n`;
    messageText += `*Customer Name:* ${customerInfo.name || 'Customer'}\n`;
    if (customerInfo.phone) {
      messageText += `*Customer Phone:* ${customerInfo.phone}\n`;
    }
    messageText += `*Payment Method:* ${customerInfo.paymentMethod.toUpperCase()}\n`;
    messageText += `-----------------------------------\n\n`;
    messageText += `*ITEMS ORDERED:*\n`;

    calculatedItems.forEach((item, index) => {
      messageText += `${index + 1}. *${item.service.name}*\n`;
      messageText += `   Qty: ${item.quantity} x Rs. ${item.unitPrice.toLocaleString()}`;
      if (item.isBulk) {
        messageText += ` _(Bulk Discount Applied!)_`;
      }
      messageText += ` = *Rs. ${item.subtotal.toLocaleString()}*\n\n`;
    });

    messageText += `-----------------------------------\n`;
    messageText += `*TOTAL AMOUNT:* *Rs. ${grandTotal.toLocaleString()}*\n`;
    if (customerInfo.notes) {
      messageText += `*Notes:* ${customerInfo.notes}\n`;
    }
    messageText += `-----------------------------------\n`;
    messageText += `Please share payment account details to finalize my order. Thank you!`;

    const whatsappUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(messageText)}`;

    window.open(whatsappUrl, '_blank');
    setOrderSent(true);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/60 backdrop-blur-xs flex justify-end">
      <div className="w-full max-w-lg bg-white h-full shadow-2xl flex flex-col justify-between animate-in slide-in-from-right duration-200">
        {/* Drawer Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-blue-600" />
            <h2 className="text-lg font-bold text-slate-900">Your Subscription Cart</h2>
            <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-blue-100 text-blue-800">
              {cartItems.reduce((sum, item) => sum + item.quantity, 0)} items
            </span>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200/80 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Drawer Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-6">
          {cartItems.length === 0 ? (
            <div className="h-64 flex flex-col items-center justify-center text-center p-6 space-y-3">
              <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center text-slate-400">
                <ShoppingBag className="w-8 h-8" />
              </div>
              <h3 className="text-base font-bold text-slate-800">Your cart is empty</h3>
              <p className="text-xs text-slate-500 max-w-xs">
                Browse our wide selection of streaming platforms, VPNs, and AI productivity tools to add items.
              </p>
              <button
                onClick={onClose}
                className="mt-2 px-4 py-2 rounded-xl bg-blue-600 text-white font-bold text-xs hover:bg-blue-700 transition-colors cursor-pointer"
              >
                Browse Subscriptions
              </button>
            </div>
          ) : (
            <>
              {/* Item List */}
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs font-semibold text-slate-500 pb-1 border-b">
                  <span>Selected Subscriptions</span>
                  <button
                    onClick={onClearCart}
                    className="text-red-500 hover:text-red-700 text-xs font-medium cursor-pointer"
                  >
                    Clear All
                  </button>
                </div>

                {calculatedItems.map((item) => (
                  <div
                    key={item.service.id}
                    className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/50 flex items-center justify-between gap-3"
                  >
                    <ServiceLogo serviceId={item.service.id} serviceName={item.service.name} className="w-10 h-10" />
                    
                    <div className="flex-1 min-w-0">
                      <h4 className="text-sm font-bold text-slate-900 truncate">
                        {item.service.name}
                      </h4>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-xs font-black text-amber-600">
                          Rs. {item.unitPrice.toLocaleString()} / ea
                        </span>
                        {item.isBulk && (
                          <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-1.5 py-0.2 rounded-md">
                            Bulk Price
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Quantity Selector inside cart */}
                    <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-lg p-0.5">
                      <button
                        onClick={() =>
                          onUpdateQuantity(item.service.id, item.quantity - 1)
                        }
                        className="p-1 hover:bg-slate-100 rounded-md text-slate-600 cursor-pointer"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="w-6 text-center text-xs font-bold text-slate-800">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() =>
                          onUpdateQuantity(item.service.id, item.quantity + 1)
                        }
                        className="p-1 hover:bg-slate-100 rounded-md text-slate-600 cursor-pointer"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>

                    <div className="text-right">
                      <div className="text-sm font-black text-slate-900">
                        Rs. {item.subtotal.toLocaleString()}
                      </div>
                      <button
                        onClick={() => onRemoveItem(item.service.id)}
                        className="text-slate-400 hover:text-red-500 text-xs mt-0.5 p-0.5 transition-colors cursor-pointer"
                        title="Remove Item"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Order Form */}
              <form onSubmit={handleSendOrder} className="bg-slate-100/70 p-4 rounded-2xl border border-slate-200/80 space-y-3">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                  <Shield className="w-3.5 h-3.5 text-blue-600" />
                  Order Details for WhatsApp Delivery
                </h4>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Your Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Enter your name"
                    value={customerInfo.name}
                    onChange={(e) =>
                      setCustomerInfo({ ...customerInfo, name: e.target.value })
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      WhatsApp Phone (Optional)
                    </label>
                    <input
                      type="tel"
                      placeholder="e.g. 0300 1234567"
                      value={customerInfo.phone}
                      onChange={(e) =>
                        setCustomerInfo({ ...customerInfo, phone: e.target.value })
                      }
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Payment Method
                    </label>
                    <select
                      value={customerInfo.paymentMethod}
                      onChange={(e) =>
                        setCustomerInfo({
                          ...customerInfo,
                          paymentMethod: e.target.value as any,
                        })
                      }
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer font-medium"
                    >
                      <option value="easypaisa">Easypaisa</option>
                      <option value="jazzcash">JazzCash</option>
                      <option value="bank">Bank Transfer</option>
                      <option value="other">Other / Ask via WhatsApp</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Special Notes / Email for Activation
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Email for YouTube/Canva invite or TV device code"
                    value={customerInfo.notes}
                    onChange={(e) =>
                      setCustomerInfo({ ...customerInfo, notes: e.target.value })
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer active:scale-98 mt-2"
                >
                  <MessageSquare className="w-4 h-4 fill-white" />
                  <span>Send Order to WhatsApp ({WHATSAPP_DISPLAY})</span>
                </button>
              </form>
            </>
          )}
        </div>

        {/* Drawer Footer Total */}
        {cartItems.length > 0 && (
          <div className="p-4 sm:p-5 border-t border-slate-200 bg-white space-y-2">
            <div className="flex justify-between items-center text-slate-600 text-xs">
              <span>Subtotal</span>
              <span>Rs. {grandTotal.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center text-slate-600 text-xs">
              <span>Delivery Fee</span>
              <span className="text-emerald-600 font-bold">FREE (Instant WhatsApp)</span>
            </div>
            <div className="flex justify-between items-center pt-2 border-t border-slate-100 text-base font-black text-slate-900">
              <span>Total Payable</span>
              <span className="text-xl text-amber-600">
                Rs. {grandTotal.toLocaleString()}
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
