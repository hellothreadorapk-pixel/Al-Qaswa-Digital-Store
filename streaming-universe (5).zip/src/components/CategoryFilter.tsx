import React from 'react';
import { Search, Tv, Shield, Laptop, Sparkles, Filter } from 'lucide-react';
import { CategoryType } from '../types';

interface CategoryFilterProps {
  activeCategory: CategoryType;
  onSelectCategory: (category: CategoryType) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  inStockOnly: boolean;
  onToggleInStock: (val: boolean) => void;
  counts: Record<CategoryType, number>;
}

export const CategoryFilter: React.FC<CategoryFilterProps> = ({
  activeCategory,
  onSelectCategory,
  searchQuery,
  onSearchChange,
  inStockOnly,
  onToggleInStock,
  counts,
}) => {
  const categoryMap: Record<CategoryType, { label: string; icon: React.ReactNode }> = {
    all: { label: 'All Services', icon: <Sparkles className="w-4 h-4" /> },
    streaming: { label: 'Streaming Platforms', icon: <Tv className="w-4 h-4" /> },
    vpn: { label: 'VPN Services', icon: <Shield className="w-4 h-4" /> },
    productivity: { label: 'More Services', icon: <Laptop className="w-4 h-4" /> },
    por: { label: 'Price on Request', icon: <Sparkles className="w-4 h-4" /> },
  };

  const renderButton = (id: CategoryType) => {
    const item = categoryMap[id];
    const isActive = activeCategory === id;
    return (
      <button
        key={id}
        onClick={() => onSelectCategory(id)}
        className={`w-full flex items-center justify-center gap-1.5 sm:gap-2 px-3 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
          isActive
            ? 'bg-slate-900 text-white shadow-xs'
            : 'bg-slate-100 text-slate-600 hover:bg-slate-200/80 hover:text-slate-900'
        }`}
      >
        {item.icon}
        <span className="truncate">{item.label}</span>
        <span
          className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold shrink-0 ${
            isActive ? 'bg-blue-600 text-white' : 'bg-slate-200 text-slate-700'
          }`}
        >
          {counts[id] || 0}
        </span>
      </button>
    );
  };

  return (
    <div className="bg-white border-b border-slate-200 py-4 px-4 sm:px-6 lg:px-8 mb-6 shadow-2xs">
      <div className="max-w-7xl mx-auto space-y-4">
        {/* Search Bar */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-3">
          {/* Search Box */}
          <div className="relative w-full">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
              <Search className="w-4 h-4" />
            </div>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Search subscriptions (e.g. Netflix, NordVPN, CapCut, Grok)..."
              className="w-full pl-10 pr-10 py-2.5 rounded-xl border border-slate-300 bg-slate-50 text-slate-900 placeholder-slate-400 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => onSearchChange('')}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-xs font-semibold text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                Clear
              </button>
            )}
          </div>
        </div>

        {/* Category Buttons Layout */}
        <div className="flex flex-col gap-2 pt-1 max-w-2xl mx-auto">
          {/* Row 1: All Services (top, centered, full-width) */}
          <div>
            {renderButton('all')}
          </div>

          {/* Row 2: Streaming Platforms & VPN Services */}
          <div className="grid grid-cols-2 gap-2">
            {renderButton('streaming')}
            {renderButton('vpn')}
          </div>

          {/* Row 3: More Services & Price on Request */}
          <div className="grid grid-cols-2 gap-2">
            {renderButton('productivity')}
            {renderButton('por')}
          </div>
        </div>
      </div>
    </div>
  );
};
